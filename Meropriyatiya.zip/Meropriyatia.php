<?php
/*
Plugin Name: Наши Мероприятия
Plugin URI: http://denis1986.esy.es
Description:  Мероприятия профсоюза
Version: 1.0
Author: VarriableID
Author URI: http://vk.com/varriableid
License: GPLv2
*/

add_action( 'init', 'create_meropriyatiya' );


function create_meropriyatiya() {
register_post_type( 'meropriyatiya',
array(
'labels' => array(
'name' => 'Наши Мероприятия',
'singular_name' => 'Наши Мероприятия',
'add_new' => 'Add New',
'add_new_item' => 'Add New Наши Мероприятия',
'edit' => 'Edit',
'edit_item' => 'Edit Наши Мероприятия',
'new_item' => 'New Наши Мероприятия',
'view' => 'View',
'view_item' => 'View Наши Мероприятия',
'search_items' => 'Search Наши Мероприятия',
'not_found' => 'No Наши Мероприятия found',
'not_found_in_trash' =>
'No Наши Мероприятия found in Trash',
'parent' => 'Parent Наши Мероприятия'
),
'public' => true,
'menu_position' => 15,
'supports' =>
array( 'title', 'editor', 'comments',
'thumbnail',  ),
'taxonomies' => array( '' ),
'menu_icon' =>
plugins_url( 'images/image.png', __FILE__ ),
'has_archive' => true
)
);
}

add_action( 'admin_init', 'my_admin' );




function my_admin() {
add_meta_box( 'meropriyatiya_meta_box',
'Наши Мероприятия Details',
'display_meropriyatiya_meta_box',
'meropriyatiya', 'normal', 'high' );
}




add_action( 'save_post',
'add_meropriyatiya_fields', 10, 2 );


function add_meropriyatiya_fields( $meropriyatiya_id,
$meropriyatiya ) {
// Check post type for Наши Мероприятия
if ( $meropriyatiya->post_type == 'meropriyatiya' ) {
// Store data in post meta table if present in post data
if ( isset( $_POST['meropriyatiya_director_name'] ) &&
$_POST['meropriyatiya_director_name'] != '' ) {
update_post_meta( $meropriyatiya_id, ' succes_director',
$_POST['meropriyatiya_director_name'] );
}
if ( isset( $_POST['meropriyatiya_rating'] ) &&
$_POST['meropriyatiya_rating'] != '' ) {
update_post_meta( $meropriyatiya_id, ' succes_rating',
$_POST['meropriyatiya_rating'] );
}
}
}


add_filter( 'template_include',
'include_template_function', 1 );


function include_template_function( $template_path ) {
if ( get_post_type() == 'meropriyatiya' ) {
if ( is_single() ) {
// checks if the file exists in the theme first,
// otherwise serve the file from the plugin
if ( $theme_file = locate_template( array
( 'single-meropriyatiya.php' ) ) ) {
$template_path = $theme_file;
} else {
$template_path = plugin_dir_path( __FILE__ ) .
'/single-meropriyatiya.php';
}
}
}
return $template_path;
}


?>