<?php
/*
Plugin Name: Наша Пресса
Plugin URI: http://denis1986.esy.es
Description:  Пресса профсоюза
Version: 1.0
Author: VarriableID
Author URI: http://vk.com/varriableid
License: GPLv2
*/

add_action( 'init', 'create_pressa' );


function create_pressa() {
register_post_type( 'pressa',
array(
'labels' => array(
'name' => 'Наша Пресса',
'singular_name' => 'Наша Пресса',
'add_new' => 'Добавить',
'add_new_item' => 'Добавить Наша Пресса',
'edit' => 'Edit',
'edit_item' => 'Edit Наша Пресса',
'new_item' => 'New Наша Пресса',
'view' => 'View',
'view_item' => 'View Наша Пресса',
'search_items' => 'Search Наша Пресса',
'not_found' => 'No Наша Пресса found',
'not_found_in_trash' =>
'No Наша Пресса found in Trash',
'parent' => 'Parent Наша Пресса'
),
'public' => true,
'menu_position' => 14,
'supports' =>
array( 'title', 'editor', 'comments',
'thumbnail',  ),
'taxonomies' => array( '' ),
'menu_icon' =>
plugins_url( 'images/image.png', __FILE__ ),
'has_archive' => true
)
);
}

add_action( 'admin_init', 'my_admin_pressa' );




function my_admin_pressa() {
add_meta_box( 'pressa_meta_box',
'Наша Пресса Details',

'pressa', 'normal', 'high' );
}




add_action( 'save_post',
'add_pressa_fields', 10, 2 );


function add_pressa_fields( $pressa_id,
$pressa ) {
// Check post type for Наша Пресса
if ( $pressa->post_type == 'pressa' ) {
// Store data in post meta table if present in post data
if ( isset( $_POST['pressa_zagolovok_name'] ) &&
$_POST['pressa_zagolovok_name'] != '' ) {
update_post_meta( $pressa_id, ' succes_zagolovok',
$_POST['pressa_zagolovok_name'] );
}
if ( isset( $_POST['pressa_rating'] ) &&
$_POST['pressa_rating'] != '' ) {
update_post_meta( $pressa_id, ' succes_rating',
$_POST['pressa_rating'] );
}
}
}


add_filter( 'template_include',
'include_template_function', 1 );


function include_template_pressa_function( $template_path ) {
if ( get_post_type() == 'pressa' ) {
if ( is_single() ) {
// checks if the file exists in the theme first,
// otherwise serve the file from the plugin
if ( $theme_file = locate_template( array
( 'single-pressa.php' ) ) ) {
$template_path = $theme_file;
} else {
$template_path = plugin_dir_path( __FILE__ ) .
'/single-pressa.php';
}
}
}
return $template_path;
}


?>