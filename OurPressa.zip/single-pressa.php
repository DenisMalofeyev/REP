<?php
/*
Template Name: Наша Пресса
*/

get_header(); ?>

<div id="primary">
	<div id="content" role="main">
	<?php query_posts(array('post_type'=>'pressa')); ?>
	<?php $mypost = array( 'post_type' => 'pressa' );
	$loop = new WP_Query( $mypost ); ?>
	<!-- Cycle through all posts -->
	<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
	<div class="col-md-12">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header">

				<!-- Display featured image in right-aligned floating div -->
				<div style="float:top; margin: 10px">
					<?php the_post_thumbnail( array(100,100) ); ?>
				</div>

				<!-- Display Title and Author Name -->
				<strong> <?php the_title(); ?></strong><br />
				

				

			</header>

			<!-- Display movie review contents -->
			<div class="entry-content"><?php the_content(); ?></div>

		</article>
</div>
		<hr/>
	<?php endwhile; ?>
	</div>
</div>
<?php wp_reset_query(); ?>
<?php get_footer(); ?>
